local json = require "modules/json"

spawnlocation = {}

function spawnlocation.onJsonDataIncoming(data)
	local decodedJson = json.decode(data)
	
	local context = rmlui.contexts["main"]
	
	if decodedJson['o'] then
		spawnlocation.document = context:LoadDocument("rml/spawnlocation/spawnlocation.rml")
		spawnlocation.document:Show()
	end
end

function spawnlocation.onSpawnChooseClicked(id)
	
	Native.sendJsonData(50, json.encode({t = id}))
	Native.sendJsonData(50, json.encode({c = 50}))
	spawnlocation.document:Close()
	spawnlocation.document = nil
end

function spawnlocation.isCursorNeeded()

	if spawnlocation.document ~= nil then
		return 1
	else
		return 0
	end
end

guis[50] = spawnlocation